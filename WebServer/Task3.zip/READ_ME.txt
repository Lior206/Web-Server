מגישים:
Lior Chen - 316522408
Erez Lev - 206281842